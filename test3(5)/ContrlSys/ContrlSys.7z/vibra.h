#ifndef __vibra_H__
#define __vibra_H__

extern int vibra_flag[5];

void Vibra_Init(void);
void Vibra_monitor(void);


#endif