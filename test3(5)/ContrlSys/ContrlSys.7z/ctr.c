#include "ctr.h"
#include "WS2812.h"
#include "dma.h"
#include "vibra.h"
#include "Cmaster.h"
#include "stdlib.h"

int Fan_num = 0;
int i_count = 0;
int Flow_flag;//1,2,3
uint8_t num=0;
uint8_t rand_num = 0;
uint8_t Rand_zu[2][5]={{0,1,2,3,4},{4,3,2,1,0}};

EnergySys ES;

/*
*�������س�ʼ��
*
**/
void EnergyMachine_Init()
{
		ES.fan[0].tim = &htim4;//PB6
    ES.fan[1].tim = &htim2;//PA15
    ES.fan[2].tim = &htim5;//PA0
    ES.fan[3].tim = &htim3;//PB1
    ES.fan[4].tim = &htim1;//PA8
    ES.fan[0].Channel = TIM_CHANNEL_1;
    ES.fan[1].Channel = TIM_CHANNEL_1;
    ES.fan[2].Channel = TIM_CHANNEL_1;
    ES.fan[3].Channel = TIM_CHANNEL_4;
    ES.fan[4].Channel = TIM_CHANNEL_1;
}

/*
*��Ҷ��ʼ��
*
*
**/
void Fan_Init()
{
	ES.fan[0].mode = 0;
	ES.fan[1].mode = 0;
	ES.fan[2].mode = 0;
	ES.fan[3].mode = 0;
	ES.fan[4].mode = 0;
	ES.fan[5].mode = 1;
	
}

/*
*
*ԲȦ��ʼ��ֵ
*
**/
void LED_YUAN_Init()
{
	uint32_t i,j;
	for(i=WS2812B_LED_QUANTITY;i<WS2812B_LED_QUANTITY+OUTER;i++)
	{
		WS2812B_Buf[i]=0x0000FF;
	}
	
	for(j=WS2812B_LED_QUANTITY;j<WS2812B_LED_QUANTITY+OUTER;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}

}

/*
*
*�߿����ֵ
*
*
**/
void LINE_Init()
{
		uint32_t i,j;
	for(i=TWO_Number;i<All_Number;i++)
	{
		WS2812B_Buf[i]=0x0000FF;
	}
	
	for(j=TWO_Number;j<All_Number;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}

}

/*
*
*���Ļ���ʼ��
*
**/
void Target_Init()
{
	
		uint32_t i,j;
	for(i=0;i<Target_Number;i++)
	{
		WS2812B_Buf[i]=0x000010;
	}
	
	for(j=0;j<Target_Number;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}

	HAL_TIM_PWM_Start_DMA(&htim8,TIM_CHANNEL_3,&WS2812B_Bit[0],24*Target_Number+1);
	HAL_Delay(30);
	Vibra_monitor();
}

/*
*��Ҷ����
*
*0-off,1-on,2-flow
*s:����ǰ���Ĳ���,RGB����Ҷ����ɫ
*
**/
void Ctr_Fan(int s,int RGB)
{
	i_count = 0;
	//ģʽ���
	Vibra_Detection();
	
	for(uint8_t j=0;j<5;j++)
	{
		if(ES.fan[j].mode == 1)
		{
			i_count = i_count + 1;
		}
	}
	if(i_count==2){
			ES.fan[5].mode = 2;
	}
	if(i_count==3){
			ES.fan[5].mode = 1;
	}
	//Ϊ�˽����Ƭ��Ҷ������ˮ���������⣬DMA����û����-����ʾ����
	
	int i;
	for(i=0;i<6;i++){
		ALL_ClearBuf();
		ALL_UpdateBuf();
		switch(ES.fan[i].mode)
		{
			case 0:
				Light_off();
				break;
			case 1:
				Light_on(RGB);
				LINE_Init();
				LED_YUAN_Init();
				break;
			case 2:
				//��ˮ��3��
				if(Flow_flag == 0){
					Light_flow(s,RGB);
					LED_YUAN_Init();
					Flow_flag = 1;
				}else if(Flow_flag == 1){
					Light_flow2(s,RGB);
					LED_YUAN_Init();
					Flow_flag = 2;
				}else if(Flow_flag == 2){
					Light_flow3(s,RGB);
							LED_YUAN_Init();
					Flow_flag = 0;
				}
				break;
		}
		
		if(i==0){
		HAL_TIM_PWM_Start_DMA(&htim4,TIM_CHANNEL_1,&WS2812B_Bit[0],24*All_Number+1);
		HAL_Delay(30);
		Vibra_monitor();
		}
		if(i==1){
		HAL_TIM_PWM_Start_DMA(&htim2,TIM_CHANNEL_1,&WS2812B_Bit[0],24*All_Number+1);
		HAL_Delay(30);
		Vibra_monitor();
		}
		if(i==2){
		HAL_TIM_PWM_Start_DMA(&htim5,TIM_CHANNEL_1,&WS2812B_Bit[0],24*All_Number+1);
		HAL_Delay(30);
		Vibra_monitor();
		}
		if(i==3){
		HAL_TIM_PWM_Start_DMA(&htim3,TIM_CHANNEL_4,&WS2812B_Bit[0],24*All_Number+1);
		HAL_Delay(30);
		Vibra_monitor();
		}
		if(i==4){
		HAL_TIM_PWM_Start_DMA(&htim1,TIM_CHANNEL_1,&WS2812B_Bit[0],24*All_Number+1);
		HAL_Delay(30);
		Vibra_monitor();
		}
		if(i==5){
		HAL_TIM_PWM_Start_DMA(&htim8,TIM_CHANNEL_3,&WS2812B_Bit[0],24*All_Number+1);
		HAL_Delay(30);
		Vibra_monitor();
		}
	}
	
}

/*
*�������ȡ
*
**/
int Rand_num()
{
	int i;
	i = rand()%4;
	return i;
}



/*
*��Ҷ�����߼�
*
*ע�⣺û�д�����
*ע�⣺û�м�¼�ư�״̬
*
*�ư��������˳��: 0 1 4 2 5
*
**/
void Fan_Logic()
{
		ES.HitErrFlag = 0;
		static uint8_t logic_check = 0;//�����߼�����
		static uint8_t logic_rand = 0;
		uint8_t i0=0,i1=1,i2=4,i3=2,i4=3;
		
	
		switch(ES.state)
		{
			case wait_activate:
			//	if(ES.last_state != wait_activate|| HAL_GetTick() - ES.timeStamp > 2500)
//					if(ES.last_state != wait_activate)
//				{
//					for(uint8_t i=0;i < 5;i++)
//					{
//						ES.fan[i].last_mode = ES.fan[i].mode;//��¼�ϸ�ģʽ
//						//�����еĵư�����
//						ES.fan[i].mode = OFF;
//					}
					for(uint8_t i; i<5; i++)
					{
						ES.fan[i].mode = OFF;
					}
//				ES.fan[ES.Need_hit].mode = OFF;
					ES.timeStamp = HAL_GetTick();//��¼ʱ��
					ES.last_state = wait_activate;//����״̬
					ES.HitErrFlag = 0;
					
	//				jilu0:	
						ES.Need_hit = i0;//Ŀ�������һ��0~4����
//						if(ES.Need_hit== ES.Need_hit_last){
//							goto jilu0;//��ֹ������ظ�
//						}
					ES.Need_hit_last = ES.Need_hit;
					ES.StateSwitch_flag = 1;//��������ָ�������
					ES.fan[ES.Need_hit].mode = Flow;//ȷ��һ���ư�
		//		}
			
				break;
				
			case activate_1: //����ư屻����
				if(ES.fan[ES.Need_hit].mode != ON && logic_check == 0)
				{
					ES.HitErrFlag = 1;
				}
				logic_check = 1;//����������һ��
				
				if(ES.last_state != activate_1 )
				{
					for(uint8_t i = 0;i<5;i++)
					{
						ES.fan[i].last_mode = ES.fan[i].mode;
					}
				//	ES.fan[ES.Need_hit].mode = ON;//�Ѿ����𶯼���ˣ��˴�Ӧ������
					ES.timeStamp = HAL_GetTick();
					ES.Alread_hit[0] = ES.Need_hit;//��¼�����еĵ�
					ES.last_state = activate_1;
					
					//jilu1:
						ES.Need_hit = i1;//���´����
//						if(ES.Need_hit == ES.Alread_hit[0] || ES.Need_hit == ES.Need_hit_last){//��֤���ظ��������ϸ��Ѿ�����ĵư�
//							goto jilu1;
//						}
					ES.Need_hit_last = ES.Need_hit;
					ES.StateSwitch_flag = 1;
					ES.fan[ES.Need_hit].mode = Flow;//ȷ��һ���ư�
				}
				break;
			
			case activate_2:
				if(ES.fan[ES.Need_hit].mode != ON && logic_check == 1)
				{
					ES.HitErrFlag = 1;
				}
				logic_check = 2;
				
				if(ES.last_state != activate_2)
				{
					for(uint8_t i;i<5;i++)
					{
						ES.fan[i].last_mode = ES.fan[i].mode;
					}
				//	ES.fan[ES.Need_hit].mode = ON;
					ES.timeStamp = HAL_GetTick();
					ES.Alread_hit[1] = ES.Need_hit;
					ES.last_state = activate_2;
					
					//jilu2:
						ES.Need_hit = i2;
//						if(ES.Need_hit == ES.Alread_hit[1] || ES.Need_hit == ES.Alread_hit[0] || ES.Need_hit == ES.Need_hit_last){
//							goto jilu2;
//						}
					ES.Need_hit_last = ES.Need_hit;
					ES.StateSwitch_flag = 1;
					ES.fan[ES.Need_hit].mode = Flow;
				}
				break;
				
			case activate_3://�޸Ĵ�
				if(ES.fan[ES.Need_hit].mode != ON && logic_check == 2)
				{
					ES.HitErrFlag = 1;
				}
				logic_check = 3;
				
				if(ES.last_state != activate_3)//�޸Ĵ�
				{
					for(uint8_t i;i<5;i++)
					{
						ES.fan[i].last_mode = ES.fan[i].mode;
					}
				//	ES.fan[ES.Need_hit].mode = ON;
					ES.timeStamp = HAL_GetTick();
					ES.Alread_hit[2] = ES.Need_hit;//�޸Ĵ�
					ES.last_state = activate_3;//�޸Ĵ�
					
					//jilu3://�޸Ĵ�
						ES.Need_hit = i3;
//						if(ES.Need_hit == ES.Alread_hit[2] || ES.Need_hit == ES.Alread_hit[1] || ES.Need_hit == ES.Alread_hit[0] || ES.Need_hit == ES.Need_hit_last){
//							goto jilu3;
//						}
					ES.Need_hit_last = ES.Need_hit;
					ES.StateSwitch_flag = 1;
					ES.fan[ES.Need_hit].mode = Flow;
				}
				break;
				
			case activate_4://�޸Ĵ�
				if(ES.fan[ES.Need_hit].mode != ON && logic_check == 3)
				{
					ES.HitErrFlag = 1;
				}
				logic_check = 4;
				
				if(ES.last_state != activate_4)//�޸Ĵ�
				{
					for(uint8_t i;i<5;i++)
					{
						ES.fan[i].last_mode = ES.fan[i].mode;
					}
			//		ES.fan[ES.Need_hit].mode = ON;
					ES.timeStamp = HAL_GetTick();
					ES.Alread_hit[3] = ES.Need_hit;//�޸Ĵ�
					ES.last_state = activate_4;//�޸Ĵ�
					
			//		jilu4://�޸Ĵ�
						ES.Need_hit = i4;
//						if(ES.Need_hit == ES.Alread_hit[3] || ES.Need_hit == ES.Alread_hit[2] || ES.Need_hit == ES.Alread_hit[1] || ES.Need_hit == ES.Alread_hit[0] || ES.Need_hit == ES.Need_hit_last){
//							goto jilu4;
//						}
					ES.Need_hit_last = ES.Need_hit;
					ES.StateSwitch_flag = 1;
					ES.fan[ES.Need_hit].mode = Flow;
				}
				break;
				
			case success_activate:
				if(ES.fan[ES.Need_hit].mode != ON && logic_check == 4)
				{
					ES.HitErrFlag = 1;
				}
				logic_check = 5;
				
				if(ES.last_state != success_activate)
				{
					for(uint8_t i=0;i<5;i++){
						ES.fan[i].last_mode = ES.fan[i].mode;
					}
			//		ES.fan[ES.Need_hit].mode = ON;
					ES.timeStamp = HAL_GetTick();//ʱ����������
					ES.Alread_hit[4] = ES.Need_hit;
//					ES.last_state = success_activate;
//					ES.StateSwitch_flag = 1;
				}
				break;
		}
}

/*
*
*���ģʽ����
*�������Լ������ģʽ��
*
**/
void Trigger_Switchstate()
{
	num = 0;
	for(uint8_t i=0;i<5;i++)
	{
		if(ES.fan[i].mode == 1)
		{
			num += 1;//��¼����״̬
		}
	}
	
	//�����Լ�
	if(ES.HitErrFlag)
	{
		__set_FAULTMASK(1);
		HAL_NVIC_SystemReset();

	}
	
	//ʱ���Լ�
//	if(HAL_GetTick() - ES.timeStamp > 2500)
//	{
//			__set_FAULTMASK(1);
//		HAL_NVIC_SystemReset();
//	}
	
	switch(num)
	{
		case 0:
			ES.state = wait_activate;
			break;
		case 1://��һ���ư屻����
			ES.state = activate_1;
			break;
		case 2://�ڶ����ư屻����
			ES.state = activate_2;
			break;
		case 3://��
			ES.state = activate_3;
			break;
		case 4://��
			ES.state = activate_4;
			break;
		case 5://��
			ES.state = success_activate;
			break;
	}
}


/*
*
*�񶯼��
*
*
**/
void Vibra_Detection()
{
	if(vibra_flag[0]==1 && ES.Need_hit == 0)
	{
		ES.fan[0].mode = 1;
	}
	if(vibra_flag[1]==1 && ES.Need_hit == 1)
	{
		ES.fan[1].mode = 1;	
	}
	if(vibra_flag[2]==1 && ES.Need_hit == 2)
	{
		ES.fan[2].mode = 1;	
	}
	if(vibra_flag[3]==1 && ES.Need_hit == 3)
	{
		ES.fan[3].mode = 1;	
	}
	if(vibra_flag[4]==1 && ES.Need_hit == 4)
	{
		ES.fan[4].mode = 1;	
	}
	
}	


/*
*�رյƹ�
*
**/
void Light_off()
{
	uint32_t i,j;
	for(i=0;i<WS2812B_LED_QUANTITY;i++)
	{
		WS2812B_Buf[i]=0x000000;
	}
	
	
	for(j=0;j<WS2812B_LED_QUANTITY;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}
	
}

/*
*�ƹ�ȫ��
*
**/
void Light_on(int RGB)
{
	
//ʹ����
	uint32_t i,j;
	for(i=0;i<WS2812B_LED_QUANTITY;i++)
	{
		WS2812B_Buf[i]=RGB;
	}
	
	for(i=TWO_Number;i<All_Number;i++)
	{
		WS2812B_Buf[i]=RGB;
	}
	
	for(j=0;j<WS2812B_LED_QUANTITY;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}
		
	for(j=TWO_Number;j<All_Number;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}
}
//////
	


/*
*һ����ˮ��
*
**/
void Light_flow(int s,int RGB)
{
	uint32_t i,j;
	Arror(0,s,RGB);
	Arror(5,s,RGB);
	Arror(10,s,RGB);
	Arror(15,s,RGB);
	Arror(20,s,RGB);
	Arror(25,s,RGB);
	Arror(30,s,RGB);	
	
	for(j=0;j<WS2812B_LED_QUANTITY;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}
}

/*
*������ˮ��
*
*
**/
void Light_flow2(int s,int RGB)
{
uint32_t i,j;
	Arror(2,s,RGB);
	Arror(7,s,RGB);
	Arror(12,s,RGB);
	Arror(17,s,RGB);
	Arror(22,s,RGB);
	Arror(27,s,RGB);
	Arror(32,s,RGB);	
	
	for(j=0;j<WS2812B_LED_QUANTITY;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}

}

/*
*������ˮ��
*
*
**/
void Light_flow3(int s,int RGB)
{
	uint32_t i,j;
	Arror(4,s,RGB);
	Arror(9,s,RGB);
	Arror(14,s,RGB);
	Arror(19,s,RGB);
	Arror(24,s,RGB);
	Arror(29,s,RGB);
	Arror(34,s,RGB);	
	
	for(j=0;j<WS2812B_LED_QUANTITY;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}

}

/*
*���Բ�ͬ�˿����
*
**/
void Test(int s,int RGB)
{
	uint32_t i,j;
	for(i=0;i<WS2812B_LED_QUANTITY+OUTER;i++)
	{
		WS2812B_Buf[i]=RGB;
	}
//	WS2812B_SetBuf(RGB);
	
	for(j=0;j<WS2812B_LED_QUANTITY+OUTER;j++)
	{
		for(i=0;i<24;i++)
		{
			if(WS2812B_Buf[j]&(0x800000>>i)){WS2812B_Bit[j*24+i+1]=45;}  //BITλΪ1 ������Ӧ��ռ�ձ�
			else{WS2812B_Bit[j*24+i+1]=25;}
		}
	}
	
}

